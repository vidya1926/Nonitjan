package testcase;

import org.testng.annotations.Test;

public class Learnannotation extends BeforeAfterAnn {

	@Test(enabled=false)
	public void test3() {
		System.out.println("Test3 is successful");
	}
	
}
