package testcase;

import org.testng.annotations.Test;

public class Learnannotation2  extends Learnannotation{
	
	
	
	@Test
	public void test1() {
		System.out.println("Test1 is successful");

	}
		
	@Test
	public void test2() {
		System.out.println("Test2 is successful");
	}
}
