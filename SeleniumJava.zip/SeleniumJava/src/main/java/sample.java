import week1.day1.Login;

public class sample {
	
	public static void main(String[] args) {
		int i=1;
		while(i>0) {
			i++;
			System.out.println(i);
		}
	}
	}


