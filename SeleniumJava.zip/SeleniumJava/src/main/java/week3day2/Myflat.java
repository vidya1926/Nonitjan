package week3day2;

public class Myflat extends Apartment{

	public static void main(String[] args) {
		
          Myflat buy=new Myflat();
          buy.underConstruction();
          buy.noOffloors();
	}

	
	public void underConstruction() {
		System.out.println("Implement my own design");
		
	}

}
