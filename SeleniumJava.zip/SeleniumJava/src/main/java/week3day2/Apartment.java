package week3day2;

public abstract class Apartment {
	
	
	public void noOffloors() {
		System.out.println("14 floor building");
	}
	
	
	public abstract void underConstruction();
	
	
	

}
