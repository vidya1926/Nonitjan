package week3day2;

public interface BankRules {

	public void KYCdoc();
	
	public void signature();
	
	public void moneyTransfer();

	
}
