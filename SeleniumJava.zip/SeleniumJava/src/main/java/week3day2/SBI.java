package week3day2;

public class SBI extends Apartment implements RBI,BankRules {

	
	public void KYCdoc() {
		System.out.println("Aadhar is enough");
		
	}

	
	public void signature() {
		System.out.println("Signature is manadtory");
		
	}

	
	
	public void deposit() {
		System.out.println("deposit with rate of interest 5%");
		
	}


	public void rateOfInterest() {
		System.out.println("loan roi is 11%");
		
	}

	
	public void underConstruction() {
	System.out.println("space given to SBI bank");
		
	}


	@Override
	public void moneyTransfer() {
		
	}


	
	

}
