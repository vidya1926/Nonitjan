package week3day2;

public interface RBI {
   //static final variable
	//static-->can be called without creating object
	//final -->constant -->cannot change the value of the variable
	int rateOfInterest =6; 
	
   public void moneyTransfer();
   
   public void deposit();
   
   public void rateOfInterest();
	
}
