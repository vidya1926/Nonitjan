package week1day1;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Bike {

	public static void main(String[] args) {

		Map<String, String> map1 = new LinkedHashMap<String, String>();
		Map<String, String> map2 = new LinkedHashMap<String, String>();
		map1.put("First",  "Glazed");
		map1.put("Second", "Blazed");
		map1.put("Third",  "Abide");
		map1.put("Fourth", "Rare");
		map1.put("Fifth",  "None");
		map1.put("Six",    "Vanish");
		map1.put("Seven",  "Spanish");
		map1.put("Eight",  "ITaly");
		map1.put("nine",   "7");
		map1.put("Ten",    "False");

		map2.put("First",  "Glazed");
		map2.put("Second", "Blazed");
		map2.put("Third",  "Abide");
		map2.put("Fourth", "Rare");
		map2.put("Fifth",  "None");
		map2.put("Seven",  "Spanish");
		map2.put("Eight",  "ITaly");
		map2.put("nine",   "7");
		map2.put("Ten",    "False");
			
		String skip_key = "Six";
		for (Entry<String, String> entry : map1.entrySet())
		{
		    String key = entry.getKey();
		    String value = entry.getValue();
		    System.out.println(key +"*********"+value);		    
		    if (!map2.containsKey(key) || !map2.get(key).equals(value)) {
		        System.out.println("Value for key " + key + " is different: " +value + " vs " + map2.get(key));
		    }
		    if (key.equals(skip_key)) {
		        continue;
		       }
		    }
		}
}
