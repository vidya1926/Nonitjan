package week1day1;

public class Car {
	public int y;
	
	public void applyBreak() {
		System.out.println("Applied Break");
	}
	
	public void soundHorn() {
		System.out.println("Applied sound horn");
	}
	
	public int noOfWheels(int x) {		
	int y=	x+2;
		return y;
		
	}
	
	public int getCountOfCar() {		
		int y=4;
		return y;
		}

	public static void main(String[] args) {
		
		Car obj=new Car();		
		obj.applyBreak();
		obj.soundHorn();
		//shortcut key to get the return type -->ctrl 2 l
	//	int noOfWheels = obj.noOfWheels(8);
		System.out.println(obj.noOfWheels(8));
			obj.getCountOfCar();
		
	}

}
