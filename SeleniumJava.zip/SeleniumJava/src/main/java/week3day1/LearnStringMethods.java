package week3day1;

public class LearnStringMethods {

	public static void main(String[] args) {
		
		int x=10;
		String s="10"; 
		
		String name="Testleaf Instiute ";			
		int length = name.length();
		System.out.println(name.length());
		
		
		char charAt = name.charAt(8);
		System.out.println(charAt+ " Space");
		
		

	}

}
