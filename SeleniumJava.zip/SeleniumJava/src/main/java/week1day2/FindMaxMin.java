package week1day2;

import java.util.Arrays;

public class FindMaxMin {

	public static void main(String[] args) {

		
		  int[] nums = {22, 3981, -19, 82, 0, 45, 37};
		  
		  Arrays.sort(nums); System.out.println(nums[0]);
		  System.out.println(nums[nums.length-1]); char[] c= {'e','b'};
		  System.out.println(c.toString());
		 
	
	 }
		
	
	
	

}
