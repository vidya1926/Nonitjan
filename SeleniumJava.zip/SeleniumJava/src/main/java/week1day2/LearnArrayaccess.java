package week1day2;

public class LearnArrayaccess {

	public static void main(String[] args) {

		int[] arr= {2,1,3,4,5,2,5,6};
		
		int length = arr.length;
		
		System.out.println(arr[3]);
		
		for(int i=0;i<length;i++) {
			
			System.out.println(arr[i]);
		}
		
		
		
		
	}

}
