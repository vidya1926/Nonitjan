package week1day2;

public class LearnForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int power =1;
		
		for(int i=0;i<=5;i++)
		{
			
			System.out.println(i +""+power);
			power=2*power;//power=2*1
			//power=2*2
			//continue;
		}
		
		
	
	}
}
