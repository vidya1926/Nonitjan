package week1day2;

public class CheckPositiveNumber {

	public static void main(String[] args) {
		
		
		/*block comment=>ctrl shift /
		 * >0 -->positive 
		 * <0 -->negative 
		 * =0  -->neutral
		 */
		
		int a=0;
		
		
		if(a>0) {
			System.out.println("Its a positive number");
		   }
		else if(a<0){
			System.out.println("Its a negative number");
		}
		else  {
			System.out.println("Its a neutral");
		}
		
		
		
	}

}
