package week1day2;

public class LearnSelectionStmt {

	public static void main(String[] args) {

		int age =16;
		//Condtional based execution
		if(age!=18  ) {
			System.out.println("No rights to Vote");
		}
		else {
			System.out.println("Rights to vote");
		}
		
		
		
		
	}

}
