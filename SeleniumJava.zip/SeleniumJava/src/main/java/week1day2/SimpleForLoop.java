package week1day2;

public class SimpleForLoop {

	public static void main(String[] args) {
		/*
		 * int i;
		 * 
		 * for( i=2;i<=15;i++) { if(i==3) { System.out.println("three"); continue;//skip
		 * the particular satisfied condition and continue next the iteration }
		 * System.out.println(i);
		 * 
		 * }
		 */
		
		
		int input=12;
		String name="Keerthana";
		char c='R';
		
		
		for(int j=15;j>0;j--)
		{
			System.out.println(j);
		}
	
		}

}
