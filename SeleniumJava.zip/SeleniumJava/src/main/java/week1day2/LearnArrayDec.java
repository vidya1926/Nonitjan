package week1day2;

public class LearnArrayDec {
	
	

	public static void main(String[] args) {
		
		//using instance way
		
		int[] num=new int[6];
		num[0]=2;
		num[1]=5;

		System.out.println(num[2]);
		
		String[] name=new String[4];
		System.out.println(name[0]);
		
		
		
		
	}
	
	
}
