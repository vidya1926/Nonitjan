package learnExceptionHandling;

public class ParentClass {

	
	public void myHouse() {
		System.out.println("Land");
	}
	
}
