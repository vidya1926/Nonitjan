package LearnInheritance;

import week1.day1.Login;

public class LearnImport extends Login{

	public static void main(String[] args) {
		LearnImport obj=new LearnImport();
		obj.enterUsername();
		obj.enterPassword();
	}
}
