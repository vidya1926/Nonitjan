package LearnInheritance;

public class MyBrotherClass extends MyFatherClass{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyBrotherClass obj=new MyBrotherClass();
		obj.flat();
		obj.independentHouse();
		obj.land();
	}

}
