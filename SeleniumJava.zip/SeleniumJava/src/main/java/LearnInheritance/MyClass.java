package LearnInheritance;

public class MyClass extends MyFatherClass{
	
	public static void main(String[] args) {
		
		MyClass obj=new MyClass();
		obj.independentHouse();
		obj.flat();
		obj.land();
		
	}

	
}
