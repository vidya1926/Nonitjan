package LearnInheritance;

public class LearnScope extends LearnAccessspecifier{

	public static void main(String[] args) {
		
		LearnScope s=new LearnScope();
		s.m1();
		s.m2();
		s.m4();

	}

}
