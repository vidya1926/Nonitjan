package LearnInheritance;

public class MyGrandfather {
	
	
	public void independentHouse() {
		System.out.println("Beautiful Individual Home");
	}
	
	public void flat() {
		System.out.println("4th floor of 14 floors");
	}

}
