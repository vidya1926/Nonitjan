package week1.day1;

public class LearnVariables {

	public static void main(String[] args) {
		//syntax to store information
		
		//datatype variable= value;
				
		int carCount=50;
		short noOfWheels=4;		
		char logo='H';		
		boolean isNew=false;		
		long phno=8943020482l;		
		float petrol=15.5f;			
		String brandName=" Hyundai";
		//naming Convention->camelCase
		
		System.out.println("Number of Cars " +carCount);
		System.out.println("Number of Wheels " +noOfWheels);
		System.out.println("Logo of the car " +logo);
		System.out.println("Is the car new? " +isNew);
		System.out.println("Contact person number "+phno);
		System.out.println("How much pertro it holds " +petrol);
		System.out.println("Car brand is "+brandName);

	}

}
