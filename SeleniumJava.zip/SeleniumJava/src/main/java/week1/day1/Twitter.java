package week1.day1;

public class Twitter {
	
	public void credentials() {
		System.out.println("Sign up");
	}

	public static void main(String[] args) {
	
		Login twit=new Login();
		twit.enterUsername();
		
		
		

	}

}
