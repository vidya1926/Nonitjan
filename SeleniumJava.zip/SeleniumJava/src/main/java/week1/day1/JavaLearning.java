package week1.day1;

import week1day1.Car;

public class JavaLearning {

	public  void main() {

		
		  System.out.println("Welocme,Happy Learning"); 
		  System.out.println(""); 
		  Car obj=new Car();
		  obj.applyBreak();
		  obj.soundHorn();
		 
	
			       
	}

}
